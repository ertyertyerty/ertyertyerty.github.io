# TVOntario Add-on

Kodi Addon for TVO.org website videos

Version 5.0.0 for Matrix, updated 2023-03-17
Version 5.0.1, updated 2024-05-04 to handle ValueError exceptions from datetime.strptime
